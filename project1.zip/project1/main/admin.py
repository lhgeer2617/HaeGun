from django.contrib import admin
from .models import Main, Comment


admin.site.register(Main)
admin.site.register(Comment)