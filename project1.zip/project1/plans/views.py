from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.http import HttpResponse
from django.views import generic
from django.utils.safestring import mark_safe
from .models import Plan, Comment
from .models import *
from .forms import PlanForm, CommentForm
from datetime import datetime




# Create your views here.
def index(request):
    plans = Plan.objects.all()
    context = {
        'plans': plans,
    }
    return render(request, 'plans/index.html', context)


def detail(request, pk):
    plan = Plan.objects.get(pk=pk)
    comment_form = CommentForm()
    comments = plan.comment_set.all()
    context = {
        'plan': plan,
        'comment_form': comment_form,
        'comments': comments,
    }
    return render(request, 'plans/detail.html', context)


@login_required
def create(request):
    if request.method == 'POST':
        form = PlanForm(request.POST)
        if form.is_valid():
            plan = form.save(commit=False)
            plan.user = request.user
            form.save()
            return redirect('plans:detail', plan.pk)
    else:
        form = PlanForm()
    context = {
        'form': form,
    }
    return render(request, 'plans/create.html', context)


@login_required
def delete(request, pk):
    plan = Plan.objects.get(pk=pk)
    if request.user == plan.user:
        plan.delete()
    return redirect('plans:index')


@login_required
def update(request, pk):
    plan = Plan.objects.get(pk=pk)
    if request.user == plan.user:
        if request.method == 'POST':
            form = PlanForm(request.POST, instance=plan)
            if form.is_valid:
                form.save()
                return redirect('plans:detail', plan.pk)
        else:
            form = PlanForm(instance=plan)
    else:
        return redirect('plans:index')
    context = {
        'plan': plan,
        'form': form,
    }
    return render(request, 'plans/update.html', context)


@login_required
def comments_create(request, plan_pk):
    plan = Plan.objects.get(pk=plan_pk)
    comment_form = CommentForm(request.POST)
    if comment_form.is_valid():
        comment = comment_form.save(commit=False)
        comment.plan = plan
        comment.comment_user = request.user
        comment_form.save()
        return redirect('plans:detail', plan.pk)
    context = {
        'plan': plan,
        'comment_form': comment_form,
    }
    return render(request, 'plans/detail.html', context)


@login_required
def comments_delete(request, plan_pk, comment_pk):
    comment = Comment.objects.get(pk=comment_pk)
    if request.user == comment.comment_user:
        comment.delete()
    return redirect('plans:detail', plan_pk)


def likes(request, plan_pk):
    plan = Plan.objects.get(pk=plan_pk)
    if plan.like_users.filter(pk=request.user.pk).exists():
        plan.like_users.remove(request.user)
    else:
        plan.like_users.add(request.user)
    return redirect('plans:index')


