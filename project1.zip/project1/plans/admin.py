from django.contrib import admin
from .models import Plan, Comment


admin.site.register(Plan)
admin.site.register(Comment)

